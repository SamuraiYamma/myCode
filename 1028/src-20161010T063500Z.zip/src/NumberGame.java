import java.util.ArrayList;
import java.util.Stack;

/**
 * Created by Ethan Carter on 9/29/2016.
 */
public class NumberGame implements NumberSlider {
    private int rows, columns, toWin;
    private int[][] board;
    private Stack saves;
    private GameStatus status = GameStatus.IN_PROGRESS;

    /***************************************************************
     * Reset the game logic to handle a board of a given dimension
     *
     * @param height the number of rows in the board
     * @param width the number of columns in the board
     * @param winningValue the value that must appear on the board to
     *                     win the game
     * @throws IllegalArgumentException when the winning value is not power of two
     *  or negative
     **************************************************************/
    @Override
    public void resizeBoard(int height, int width, int winningValue) {

        String temp;
        if(winningValue % 2 != 0 || winningValue < 0){
            throw new IllegalArgumentException("Winning Value is " +
                    "either negative or not a multiple of two.");
        }
        else{
            this.rows = height;
            this.columns = width;
            this.toWin = winningValue;

            board = new int[rows][columns];

            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < columns; c++) {
                    this.board[r][c] = 0;
                    temp = "" + this.board[r][c];
                }
            }
        }
    }

    /*******************************************************************
     * Remove all numbered tiles from the board and place
     * TWO non-zero values at random location
     ******************************************************************/
    @Override
    public void reset() {
        board = new int[rows][columns];

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < columns; c++) {
                this.board[r][c] = 0;
            }
        }
        status = GameStatus.IN_PROGRESS;

        placeRandomValue();
        placeRandomValue();
    }

    /*******************************************************************
     * Set the game board to the desired values given in the 2D array.
     * This method should use nested loops to copy each element from the
     * provided array to your own internal array. Do not just assign the
     * entire array object to your internal array object. Otherwise,
     * your internal array may get corrupted by the array used in the
     * JUnit test file. This method is mainly used by the JUnit
     * tester. Throws IllegalArgumentException if ref is null
     *
     * @param ref
     *
     * @exception IllegalArgumentException
     ******************************************************************/
    @Override
    public void setValues(int[][] ref) {
        if (ref == null){
            throw new IllegalArgumentException("Can't set board to " +
                    "null state");
        }
        else {
            for (int r = 0; r < ref.length; r++) {
                for (int c = 0; c < ref.length; c++) {
                    this.board[r][c] = ref[r][c];
                }
            }
        }
    }

    /**
     * Insert one random tile into an empty spot on the board.
     *
     * @return a Cell object with its row, column, and value attributes
     * initialized properly
     * @throws IllegalStateException when the board has no empty cell
     */
    @Override
    public Cell placeRandomValue() {
        ArrayList<Cell> list = getEmptyCells();

        if (!getEmptyCells().isEmpty()) {
            int index = (int) (Math.random() * list.size()) %
                    list.size();
            Cell emptyCell = list.get(index);
            int twoOrFour = twoOrFour();
            emptyCell.value = twoOrFour;

            //hears row and column and places value there
            board[emptyCell.row][emptyCell.column] = emptyCell.value;


            return emptyCell;
        }
        else {
            throw new IllegalStateException();
        }
    }

    /**
     * Slide all the tiles in the board in the requested direction
     *
     * @param dir move direction of the tiles
     * @return true when the board changes
     */
    @Override
    public boolean slide(SlideDirection dir) {
        //depending on direction, read current array a certain way
        //and deposit the values in x amount of array lists
        //return true
        switch (dir) {
            case UP:
                //utilize up helper
                break;
            case DOWN:
                //utilize down helper
                break;
            case RIGHT:
                //utilize right helper
                break;
            case LEFT:
                //utilize left helper
                break;
            //save the game (this should already be true)
            //boards.add(this.board);
        }
        return false;
    }

    /**
     * returns a list of cells that are not empty
     * @return list
     */
    @Override
    public ArrayList<Cell> getNonEmptyTiles() {
        final ArrayList<Cell> list = intToList();
        ArrayList<Cell> boardList = intToList();
        for(Cell cell : boardList){
            if(cell.value == 0){
                list.remove(cell);
            }
        }
        return list;
    }

    /**
     * Return the current state of the game
     *
     * @return one of the possible values of GameStatus enum
     */
    @Override
    public GameStatus getStatus() {
        Cell temp;
        Cell largest = new Cell();
        status = GameStatus.IN_PROGRESS;

        //compare the first item in a list of tiles to find the largest
        ArrayList<Cell> list = getNonEmptyTiles();
        temp = list.get(0);
        for (int i = 1; i < list.size(); i++) {
            if (list.get(i).compareTo(list.get(i - 1)) > 0) {
                largest = list.get(i);
            } else {
                largest = temp;
            }
        }

        //if you cant move, then you lose
        if (!canMove()) {
            status = GameStatus.USER_LOST;
        }
        //if any of the cells with values has a value of 1024 you win
        else if (largest.value >= toWin) {
            status = GameStatus.USER_WON;
        }

        return status;
    }

    /**
     * Undo the most recent action, i.e. restore the board to its previous
     * state. Calling this method multiple times will ultimately restore
     * the gam to the very first initial state of the board holding two
     * random values. Further attempt to undo beyond this state will throw
     * an IllegalStateException.
     *
     * @throws IllegalStateException when undo is not possible
     */
    @Override
    public void undo() {
        //if its empty, throw exception
        if(saves.isEmpty()){
            throw new IllegalStateException();
        }
        //otherwise pop the most recent object.
        else{
            saves.pop();
        }
    }

    /**
     * this is a totally crap way to do this. It works though.
     *
     * @return either 2 or 4
     */
    private static int twoOrFour() {
        return (int) (((Math.random() * 10) / 5) + 1) * 2;
    }

    /**
     * returns array list of cells with a value of 0
     *
     * @return list
     */
    private ArrayList<Cell> getEmptyCells() {
        final ArrayList<Cell> list = new ArrayList<>();
        ArrayList<Cell> boardList = intToList();
        for(Cell cell : boardList){
            if(cell.isEmpty()){
                list.add(cell);
            }
        }
        return list;
    }

    /**
     * returns a list of Cells from the board that have values other
     * than 0
     *
     * @return list
     */
    private ArrayList<Cell> getCells() {
        final ArrayList<Cell> list = new ArrayList<>();
        ArrayList<Cell> boardList = intToList();
        for(Cell cell : boardList){
            if(cell.hasValue()){
                list.add(cell);
            }
        }

        return list;
    }

    /**
     * returns a list of Cells for each element in the board
     * @return list
     */
    private ArrayList<Cell> intToList(){
        ArrayList<Cell> list = new ArrayList<>();

        for(int r = 0; r < rows; r++){
            for(int c = 0; c < columns; c++){
                list.add(new Cell(r,c,board[r][c]));
            }
        }
        return list;
    }

    /**
     * if the list of non empty tiles is equal to maximum possible
     * tiles on the board, then it is full so it returns false. Any
     * other time it returns true.
     *
     * @return true or false
     */
    private boolean canMove() {
        ArrayList<Cell> list = getNonEmptyTiles();
        if (list.size() == (rows * columns)) {
            return false;
        }
        return true;
    }

    /**
     * returns the board
     * @return
     */
    public int[][] getBoard(){
        return board;
    }

    private void left(){

    }



}
