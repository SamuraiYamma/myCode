/**
 * Created by dulimarh on 7/10/14.
 */
public enum SlideDirection {LEFT, UP, RIGHT, DOWN}
