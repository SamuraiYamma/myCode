/**
 * Created by SirBlooby on 10/7/2016.
 */
public class BasicTester {
    public static void main(String[] arg){
        NumberGame game = new NumberGame();

        game.resizeBoard(4,4,1024);
        game.reset();
        printBoard(game.getBoard());
        System.out.println();

        game.slide(SlideDirection.LEFT);
        printBoard(game.getBoard());
    }

    private static void printBoard(int[][] board){
        for (int i = 0; i < board.length; i++){
            for(int j = 0; j < board.length; j++){
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }
}
